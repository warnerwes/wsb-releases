TEMPLATE = app
TARGET = camera

QT += multimedia multimediawidgets
CONFIG += add_ios_ffmpeg_libraries

HEADERS = \
    camera.h \
    imagesettings.h \
    videosettings.h \
    metadatadialog.h

SOURCES = \
    main.cpp \
    camera.cpp \
    imagesettings.cpp \
    videosettings.cpp \
    metadatadialog.cpp

FORMS += \
    imagesettings.ui

android|ios {
    FORMS += \
        camera_mobile.ui \
        videosettings_mobile.ui
} else {
    FORMS += \
        camera.ui \
        videosettings.ui
}
RESOURCES += camera.qrc

target.path = $$[QT_INSTALL_EXAMPLES]/multimedia/camera
INSTALLS += target

QT += widgets

macos: QMAKE_INFO_PLIST = Info.qmake.macos.plist
ios: QMAKE_INFO_PLIST = Info.qmake.ios.plist

ANDROID_PACKAGE_SOURCE_DIR = $$PWD/android
OTHER_FILES += android/AndroidManifest.xml
