TEMPLATE = app
TARGET = audiorecorder

QT += multimedia
CONFIG += add_ios_ffmpeg_libraries

win32:INCLUDEPATH += $$PWD

HEADERS = \
    audiorecorder.h
SOURCES = \
    main.cpp \
    audiorecorder.cpp
FORMS += audiorecorder.ui

target.path = $$[QT_INSTALL_EXAMPLES]/multimedia/audiorecorder
INSTALLS += target

QT+=widgets

macos: QMAKE_INFO_PLIST = Info.qmake.macos.plist
ios: QMAKE_INFO_PLIST = Info.qmake.ios.plist

