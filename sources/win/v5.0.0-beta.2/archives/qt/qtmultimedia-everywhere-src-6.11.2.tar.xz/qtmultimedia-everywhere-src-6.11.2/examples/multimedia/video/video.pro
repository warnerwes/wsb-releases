TEMPLATE = subdirs

SUBDIRS += qmlvideo
